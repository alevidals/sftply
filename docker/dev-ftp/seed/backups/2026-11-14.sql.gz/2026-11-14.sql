-- sftply demo backup, 2026-11-14
CREATE TABLE accounts (id integer PRIMARY KEY, email text NOT NULL, created_at timestamptz NOT NULL);
CREATE TABLE projects (id integer PRIMARY KEY, owner_id integer NOT NULL REFERENCES accounts(id), name text NOT NULL);
INSERT INTO accounts (id, email, created_at) VALUES (1, 'demo@sftply.dev', '2026-10-01T09:12:00Z');
INSERT INTO projects (id, owner_id, name) VALUES (1, 1, 'website'), (2, 1, 'sftply'), (3, 1, 'archive');
